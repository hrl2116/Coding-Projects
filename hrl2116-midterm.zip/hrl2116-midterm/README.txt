﻿Name: Hannah Luo
UNI: hrl2116
HW Number: Midterm


Brief descriptions of the functions I implemented:


In effects.py:
* object_filter:
   * object_filter takes in 3 input files and outputs a new file that combines the pixels from the majority of the images to produce a singular text file ppm
      * Does this by using the mode function from statistics
* shades_of_gray:
   *  shades_of_gray takes in a single input file and returns a black and white version of it by averaging the values of the RBG pixel components
      * Does this by using the mean function from statistics
      * Mean has to be added to the output file 3 times
* horizontal_flip
   * horizontal_flip takes in a single input file and creates an output file that is a horizontal mirror of the original file. It does this by taking a list of lists and reversing it
      * Utilized a numpy array in order to reshape the list so that each row in the list corresponded to a row of pixels in the image