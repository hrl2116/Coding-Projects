########################
# Midterm tester
# ENGI 1006
# Name: Hannah Luo
# UNI: hrl2116
# File effects_tester.py contains the main method to test effects.py. It
# prompts the user for input on what actions they would like to do, as well as
# the names of the input and output file(s)
########################

from effects import object_filter, shades_of_gray, horizontal_flip

def main():
    
    output_file = ""
    print("Welcome to Portable Pixmap (PPM) Image Editor!")
    print("Choose the  effect you would like to try: ")
    print('1) object_filter')
    print('2) shades_of_gray')
    print('3) horizontal_flip')
    
    user_input = input('Enter a number: ')
        
    
    
    if user_input == "1":
        input_file1 = input('Enter the name of the input file ')
        input_file2 = input('Enter the name of the input file ')
        input_file3 = input('Enter the name of the input file ')
        
        output_file = input('Enter the name of your output file: ')
        
        object_filter(input_file1, input_file2, input_file3, output_file) 
        
    elif user_input == "2":
        inputFile = input('Enter your input file name: ')
        output_file = input('Enter the name of your output file: ')
        shades_of_gray(inputFile, output_file)
        
    elif user_input == "3":
        inputFile = input('Enter your input file name: ')
        output_file = input('Enter the name of your output file: ')
        horizontal_flip(inputFile, output_file)
        
    print(output_file, " created.")
        
    
    
if __name__ == "__main__":
    main()
