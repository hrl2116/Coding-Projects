########################
# Midterm
# ENGI 1006
# Name: Hannah Luo
# UNI: hrl2116
# File effects.py contains the midterm with functions object_filter,
# shades_of_gray, and horizontal_flip which all serve to alter a ppm image by
# changing the file
########################

from statistics import mean, mode
import numpy as np

'''
object_filter takes in 3 input files and outputs a new file that combines the
pixels from the majority of the images to produce a singular text file ppm
'''
def object_filter(infile1, infile2, infile3, outfile):
    #first step: open files for reading/writing
    in1 = open(infile1, 'r')
    in2 = open(infile2, 'r')
    in3 = open(infile3, 'r')
    outputfile = open(outfile, 'w')
    
    
    #reads the first line of input1
    line1 = in1.readline()
    line1 = in1.readline()
    
    #lines2 = input2.readlines()
    #lines3 = input3.readlines()
    
    #the dimensions are in the second line
    dimensions = line1.split(" ")
    
    #getting the rest of the readers in the files to the fourth line
    
    line1 = in1.readline()
    
    line2 = in2.readline()
    line2 = in2.readline()
    line2 = in2.readline()
    
    line3 = in3.readline()
    line3 = in3.readline()
    line3 = in3.readline()
    
    #for some reason according to the midterm pdf it's columns x rows
    #I'm assuming the dimensions are the same for all three input files
    cols = int(dimensions[0])
    rows = int(dimensions[1])

    #writing the header
    outputfile.write("P3 \n")
    outputfile.write(str(cols) + " " + str(rows) + "\n")
    outputfile.write("255 \n")
    
    #the lines for each image, without the first 3 lines/dimension/color info
    line1 = in1.readline()
    line2 = in2.readline()
    line3 = in3.readline()
    
    while(len(line1) != 0):
        line1arr = line1.split(" ")
        line2arr = line2.split(" ")
        line3arr = line3.split(" ")
        for i in range(len(line1arr)):
            
            #resets with each iteration of the for loop
            pixel = []
            pixel.append(line1arr[i])
            pixel.append(line2arr[i])
            pixel.append(line3arr[i])
            
            #finding and appending the mode
            pixel_mode = mode(pixel)
            outputfile.write(pixel_mode)
            outputfile.write(" ")
        outputfile.write("\n")
        line1 = in1.readline()
        line2 = in2.readline()
        line3 = in3.readline()
    
    #closing the files    
    in1.close()
    in2.close()
    in3.close()
    outputfile.close() 
    
'''
 shades_of_gray takes in a single input file and returns a black and white
 version of it by averaging the values of the RBG pixel components
'''   
def shades_of_gray(input_file, output_file):
    
    input1 = open(input_file, 'r')
    out = open(output_file, 'w')
    
    #reads the first line of input1
    line1 = input1.readline()
    line1 = input1.readline()
    
    #lines2 = input2.readlines()
    #lines3 = input3.readlines()
    
    #the dimensions are in the second line
    dimensions = line1.split(" ")
    
    #getting the readers in the file to the fourth line
    
    line1 = input1.readline()
    
    #for some reason according to the midterm pdf it's columns x rows
    #I'm assuming the dimensions are the same for all three input files
    cols = int(dimensions[0])
    rows = int(dimensions[1])

    #writing the header
    out.write("P3 \n")
    out.write(str(cols) + " " + str(rows) + "\n")
    out.write("255 \n")
    
    #the lines for each image, without the first 3 lines/dimension/color info
    line1 = input1.readline()
    
    while(len(line1) != 0):
        #default split is any whitespace
        line1arr = line1.split()
        for i in range(0, len(line1arr) - 2, 3):
            
            #resets with each iteration of the for loop
            pixel = []
            pixel.append(int(line1arr[i]))
            pixel.append(int(line1arr[i + 1]))
            pixel.append(int(line1arr[i + 2]))
            #finding and appending the mean 3 times
            pixel_mean = str(mean(pixel))
            for i  in range(3):
                out.write(pixel_mean)
                out.write(" ")
        out.write("\n")
        line1 = input1.readline()
    
    #closing the files    
    input1.close()
    out.close()

'''
horizontal_flip takes in a single input file and creates an output file that
is a horizontal mirror of the original file. It does this by taking a list
of lists and reversing it
'''    
def horizontal_flip(input_file, output_file):
    input1 = open(input_file, 'r')
    out = open(output_file, 'w')
    
    #reads the first line of input1
    line1 = input1.readline()
    line1 = input1.readline()
    
    #lines2 = input2.readlines()
    #lines3 = input3.readlines()
    
    #the dimensions are in the second line
    dimensions = line1.split(" ")
    
    #getting the readers in the file to the fourth line
    
    line1 = input1.readline()
    
    
    
    #for some reason according to the midterm pdf it's columns x rows
    #I'm assuming the dimensions are the same for all three input files
    cols = int(dimensions[0])
    rows = int(dimensions[1])
    
    #making a numpy array and reshaping it so that each row of the np array
    #corresponds with one row of pixels in the image
    values = input1.read()
    arr = values.split()
    np_arr = np.array(arr)
    np_arr = np_arr.reshape(rows, cols * 3)
    
    #writing the header
    out.write("P3 \n")
    out.write(str(cols) + " " + str(rows) + "\n")
    out.write("255 \n")
    
    
    #creating a list of list of lists
    for i in range(0, rows):
        arr_of_arr_of_arr = []
        for j in range(0, cols * 3, 3):
            arr_of_arr_of_arr.append(np_arr[i][j:j + 3])
        
        #reducing it to a list of lists
        arr_of_arr = []
        for sublist in arr_of_arr_of_arr:
            arr_of_arr.append(sublist)
        
        #reversing the list of lists, but the order of the RBG is not changed
        arr_of_arr.reverse()
        
        #reducing the list of lists to a list
        arr_straight = []
        for sublist in arr_of_arr:
            for item in sublist:
                arr_straight.append(item)
        
        for i in range(len(arr_straight)):
            out.write(str(arr_straight[i]))
            out.write(" ")
        out.write("\n")
        
    '''
    #the lines for each image, without the first 3 lines/dimension/color info
    line1 = input1.readline()
    
    
    while(len(line1) != 0):
        line_arr = line1.split()
        arr_of_arr = []
        for i in range(0, len(line_arr), 3):
            
            arr_of_arr.append(line_arr[i:i + 3])
            
        arr_of_arr.reverse()

        arr_straight = [item for sublist in arr_of_arr for item in sublist]
        
        for i in range(len(arr_straight)):
            out.write(str(arr_straight[i]))
            out.write(" ")
        out.write("\n")
        line1 = input1.readline()
    '''
    
    #closing the files
    input1.close()
    out.close()
            
        